/*
 * @description: 描述信息
 * @Author: Cheng kaixuan
 * @Date: 2024-01-18 13:55:21
 * @LastEditors: why
 * @LastEditTime: 2025-02-13 16:48:24
 */
const getters = {
  tag: (state) => state.tags.tag,
  language: (state) => state.common.language,
  website: (state) => state.common.website,
  userInfo: (state) => state.user.userInfo,
  applyUserInfo: (state) => state.user.applyUserInfo,
  clientUserInfo: (state) => state.user.clientUserInfo,
  colorName: (state) => state.common.colorName,
  themeName: (state) => state.common.themeName,
  isShade: (state) => state.common.isShade,
  isCollapse: (state) => state.common.isCollapse,
  keyCollapse: (state, getters) =>
    getters.screen > 1 ? getters.isCollapse : false,
  screen: (state) => state.common.screen,
  isLock: (state) => state.common.isLock,
  isFullScren: (state) => state.common.isFullScren,
  isMenu: (state) => state.common.isMenu,
  lockPasswd: (state) => state.common.lockPasswd,
  tagList: (state) => state.tags.tagList,
  tagWel: (state) => state.tags.tagWel,
  token: (state) => state.user.token,
  roles: (state) => state.user.roles,
  permission: (state) => state.user.permission,
  menu: (state) => state.user.menu,
  menuId: (state) => state.user.menuId,
  menuAll: (state) => state.user.menuAll,
  logsList: (state) => state.logs.logsList,
  logsLen: (state) => state.logs.logsList.length || 0,
  logsFlag: (state, getters) => getters.logsLen === 0,
  flowRoutes: (state) => state.dict.flowRoutes,
  aliveRoutes: (state) => state.common.aliveRoutes,
  dialogVisible: (state) => state.apply.dialogVisible,
  applayShow: (state) => state.apply.applayShow,
  showNavbarPhone: (state) => state.apply.showNavbarPhone,
  centerActive: (state) => state.common.centerActive,
  routerHistory: state => state.common.routerHistory,
};
export default getters;
